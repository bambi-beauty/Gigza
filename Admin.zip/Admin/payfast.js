// =============================================
// GIGZA — PAYFAST CONNECTOR
// =============================================
//
// ⚠️ READ THIS BEFORE GOING LIVE ⚠️
// PayFast requires every payment to be "signed" using a secret passphrase.
// That passphrase must NEVER live in code that runs in someone's browser —
// anyone could open dev tools and steal it, then fake payments.
//
// This file signs payments in the browser ONLY so you can click through the
// whole booking flow right now, against PayFast's free sandbox (fake money,
// safe to test with). Before you take real payments, this signing step needs
// to move to your backend server:
//   1. Browser sends booking details to your server (e.g. POST /api/create-payment)
//   2. Server generates the signature using the passphrase (kept secret, server-side only)
//   3. Server sends back the signed fields
//   4. Browser submits those fields to PayFast
//
// Also: never trust that a payment succeeded just because the user got
// redirected back to your "success" page — that page can be faked or skipped.
// PayFast also sends a separate, server-to-server confirmation called an ITN
// (Instant Transaction Notification) to a "notify_url" you provide. Only mark
// a booking as truly paid once your server has checked that ITN with PayFast.
// This demo skips that step since there's no backend yet — see the comments
// in booking.js for where that piece plugs in later.

const PAYFAST_CONFIG = {
  // Official PayFast sandbox test credentials (published by PayFast for public
  // testing — not secret, safe to use for trying the flow out).
  merchantId: '10000100',
  merchantKey: '46f0cd694581a',
  passphrase: '', // sandbox accounts usually have no passphrase set by default
  processUrl: 'https://sandbox.payfast.co.za/eng/process'
  // When ready to go live: processUrl becomes 'https://www.payfast.co.za/eng/process'
  // and merchantId/merchantKey/passphrase come from your real PayFast account,
  // generated server-side as described above.
};

// ---------- MD5 (needed because PayFast signatures use MD5, and browsers don't
// have a built-in MD5 function — only newer, more secure hash types) ----------
function md5(string) {
  function rotateLeft(n, s) { return (n << s) | (n >>> (32 - s)); }
  function addUnsigned(x, y) {
    const x8 = x & 0x80000000, y8 = y & 0x80000000;
    const x4 = x & 0x40000000, y4 = y & 0x40000000;
    const result = (x & 0x3fffffff) + (y & 0x3fffffff);
    if (x4 & y4) return result ^ 0x80000000 ^ x8 ^ y8;
    if (x4 | y4) {
      if (result & 0x40000000) return result ^ 0xc0000000 ^ x8 ^ y8;
      return result ^ 0x40000000 ^ x8 ^ y8;
    }
    return result ^ x8 ^ y8;
  }
  function F(x, y, z) { return (x & y) | (~x & z); }
  function G(x, y, z) { return (x & z) | (y & ~z); }
  function H(x, y, z) { return x ^ y ^ z; }
  function I(x, y, z) { return y ^ (x | ~z); }
  function convertToWordArray(str) {
    const bytes = [];
    for (let i = 0; i < str.length; i++) bytes.push(str.charCodeAt(i) & 0xff);
    const msgLength = bytes.length;
    const numWords = (((msgLength + 8) >> 6) + 1) * 16;
    const words = new Array(numWords).fill(0);
    for (let i = 0; i < msgLength; i++) {
      words[i >> 2] |= bytes[i] << ((i % 4) * 8);
    }
    words[msgLength >> 2] |= 0x80 << ((msgLength % 4) * 8);
    words[numWords - 2] = msgLength * 8;
    return words;
  }
  function wordToHex(n) {
    let hex = '';
    for (let i = 0; i <= 3; i++) {
      const byte = (n >>> (i * 8)) & 255;
      hex += ('0' + byte.toString(16)).slice(-2);
    }
    return hex;
  }

  const x = convertToWordArray(unescape(encodeURIComponent(string)));
  let a = 0x67452301, b = 0xefcdab89, c = 0x98badcfe, d = 0x10325476;

  const S = [7,12,17,22,7,12,17,22,7,12,17,22,7,12,17,22,
             5,9,14,20,5,9,14,20,5,9,14,20,5,9,14,20,
             4,11,16,23,4,11,16,23,4,11,16,23,4,11,16,23,
             6,10,15,21,6,10,15,21,6,10,15,21,6,10,15,21];
  const K = [];
  for (let i = 0; i < 64; i++) K[i] = Math.floor(Math.abs(Math.sin(i + 1)) * 4294967296);

  for (let k = 0; k < x.length; k += 16) {
    const AA = a, BB = b, CC = c, DD = d;
    for (let i = 0; i < 64; i++) {
      let f, g;
      if (i < 16) { f = F(b, c, d); g = i; }
      else if (i < 32) { f = G(b, c, d); g = (5 * i + 1) % 16; }
      else if (i < 48) { f = H(b, c, d); g = (3 * i + 5) % 16; }
      else { f = I(b, c, d); g = (7 * i) % 16; }
      const temp = d;
      d = c;
      c = b;
      f = addUnsigned(a, addUnsigned(addUnsigned(f, K[i]), x[k + g]));
      b = addUnsigned(b, rotateLeft(f, S[i]));
      a = temp;
    }
    a = addUnsigned(a, AA);
    b = addUnsigned(b, BB);
    c = addUnsigned(c, CC);
    d = addUnsigned(d, DD);
  }
  return (wordToHex(a) + wordToHex(b) + wordToHex(c) + wordToHex(d)).toLowerCase();
}

// ---------- BUILD THE PAYMENT FIELDS ----------
// PayFast checks the signature against the fields in a specific order, so we
// build them as one ordered object rather than adding them in random order.
function buildPayfastFields(booking) {
  const [nameFirst, ...rest] = (booking.clientName || 'Guest').trim().split(' ');
  const nameLast = rest.join(' ') || nameFirst;
  const baseUrl = `${window.location.origin}${window.location.pathname}`;

  return {
    merchant_id: PAYFAST_CONFIG.merchantId,
    merchant_key: PAYFAST_CONFIG.merchantKey,
    return_url: `${baseUrl}?status=success&ref=${encodeURIComponent(booking.ref)}`,
    cancel_url: `${baseUrl}?status=cancelled&ref=${encodeURIComponent(booking.ref)}`,
    // In production this points at your backend, e.g. https://api.gigza.co.za/payments/payfast-notify
    // PayFast calls this URL directly (not through the customer's browser) to confirm
    // the payment really happened. That's the only confirmation you should ever trust.
    notify_url: 'https://your-api.com/api/payments/payfast-notify',
    name_first: nameFirst,
    name_last: nameLast,
    email_address: booking.clientEmail,
    cell_number: booking.clientPhone || '',
    m_payment_id: booking.ref, // your own reference — must be unique per payment
    amount: Number(booking.total).toFixed(2),
    item_name: `Gigza booking: ${booking.djName}`,
    item_description: `${booking.eventType} on ${booking.eventDate}`,
    // Tucking the DJ id into a custom field means your backend's ITN handler can
    // look up who to pay out later without needing to trust anything else the
    // browser sends.
    custom_str1: String(booking.djId)
  };
}

// ---------- SIGN THE PAYMENT ----------
function generateSignature(fields) {
  const pairs = [];
  for (const key in fields) {
    const value = fields[key];
    if (value !== undefined && value !== null && String(value).trim() !== '') {
      pairs.push(`${key}=${encodeURIComponent(String(value).trim()).replace(/%20/g, '+')}`);
    }
  }
  let paramString = pairs.join('&');
  if (PAYFAST_CONFIG.passphrase) {
    paramString += `&passphrase=${encodeURIComponent(PAYFAST_CONFIG.passphrase.trim()).replace(/%20/g, '+')}`;
  }
  return md5(paramString);
}

// ---------- SEND THE BROWSER TO PAYFAST ----------
function submitToPayfast(booking) {
  const fields = buildPayfastFields(booking);
  fields.signature = generateSignature(fields);

  const form = document.createElement('form');
  form.method = 'POST';
  form.action = PAYFAST_CONFIG.processUrl;
  form.style.display = 'none';

  Object.entries(fields).forEach(([key, value]) => {
    if (value === undefined || value === null || value === '') return;
    const input = document.createElement('input');
    input.type = 'hidden';
    input.name = key;
    input.value = value;
    form.appendChild(input);
  });

  document.body.appendChild(form);
  form.submit();
}

window.gigzaPayfast = { submitToPayfast, buildPayfastFields, generateSignature, md5 };
