// ---------- SAFETY HELPERS ----------
// Applicant-entered text (name, bio, location, etc.) must NEVER be put straight into
// innerHTML. Otherwise a DJ could put something like <img src=x onerror="steal admin
// cookies"> in their bio, and it would run inside the admin's own browser session the
// moment an admin views their profile. escapeHtml() turns that into harmless plain text.
function escapeHtml(value) {
  if (value === null || value === undefined) return '';
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

// Only allow http/https links to be rendered as clickable <a href="...">.
// Without this, a portfolio URL like "javascript:alert(document.cookie)" would
// execute code when an admin clicks it.
function safeUrl(url) {
  if (!url) return '';
  try {
    const parsed = new URL(url, window.location.href);
    if (parsed.protocol === 'http:' || parsed.protocol === 'https:') {
      return parsed.href;
    }
  } catch (e) {
    // not a valid URL — fall through and return nothing
  }
  return '';
}

const adminSession = sessionStorage.getItem('gigza_admin_session');

if (!adminSession) {
  window.location.href = 'admin-login.html';
} else {
  const admin = JSON.parse(adminSession);
  console.log(`👋 Welcome back, ${admin.name} (${admin.role})`);

}

// Add logout function
function handleLogout() {
  if (confirm('Are you sure you want to logout?')) {
    sessionStorage.removeItem('gigza_admin_session');
    window.location.href = 'admin-login.html';
  }
}
// This is just sample data it should be replace with our API calls
let djs = [
  // ============================================
  // DJ 1: Strong candidate — should auto-approve
  // ============================================
  {
    id: 1,
    name: 'DJ Zee',
    email: 'djzee@email.com',
    phone: '+27 81 234 5678',
    type: 'dj',
    genre: 'Amapiano',
    genres: ['Amapiano', 'Deep House', 'Afro Tech'],
    location: 'Sandton, Johannesburg',
    experience: 3,
    bio: 'Passionate Amapiano DJ with residency at Club Vibe. Specialized in private events and corporate functions. Available for bookings nationwide. Contact me for rates and availability.',
    portfolioUrl: 'https://soundcloud.com/djzee',
    idDocument: 'id_zee.pdf',
    idNumber: '9901015000086',
    idName: 'Zee Khumalo',
    fullName: 'Zee Khumalo',
    profilePhoto: 'profile_zee.jpg',
    idPhoto: 'id_photo_zee.jpg',
    dateOfBirth: '1999-01-01',
    mixCount: 8,
    avgMixDuration: 1800,
    avgBitrate: 320,
    hasLiveSets: true,
    hasTracklists: true,
    livenessVerified: false,
    socialLinks: {
      instagram: {
        followers: 3200,
        avgLikes: 180,
        avgComments: 25,
        accountAge: 500,
        followerToFollowingRatio: 1.5
      },
      tiktok: {
        followers: 8500,
        avgLikes: 400,
        avgComments: 60,
        accountAge: 300,
        followerToFollowingRatio: 2.0
      }
    },
    equipment: ['Pioneer DDJ-1000', 'MacBook Pro', 'Sennheiser Headphones'],
    pricing: 2500,
    bankDetails: { bankName: 'FNB', accountHolder: 'Zee Khumalo', accountNumber: '62812345678', branchCode: '250655' },
    availability: ['weekends', 'evenings', 'public holidays'],
    appliedDate: '2025-04-10',
    status: 'pending',
    reports: 0,
    previousRejections: 0,
    applicationCount: 1,
    emailDomain: 'email.com',
    applicationSpeed: 300
  },

  // ============================================
  // DJ 2: Suspicious — should flag for review
  // ============================================
  {
    id: 2,
    name: 'DJ Killer',
    email: 'killerdj@mailinator.com',
    phone: '+27 72 345 6789',
    type: 'dj',
    genre: 'Gqom',
    genres: ['Gqom'],
    location: 'Durban Central',
    experience: 5,
    bio: 'Best DJ in Africa 💯💯💯 Number one in the game. No competition. 100% guarantee you will love my sets. Make money fast with me.',
    portfolioUrl: '',
    idDocument: '',
    idNumber: '1234567890123',
    idName: 'Killer D',
    fullName: 'DJ Killer',
    profilePhoto: 'profile_killer.jpg',
    idPhoto: '',
    dateOfBirth: '1990-01-01',
    mixCount: 0,
    avgMixDuration: 0,
    avgBitrate: 0,
    hasLiveSets: false,
    hasTracklists: false,
    livenessVerified: false,
    socialLinks: {
      instagram: {
        followers: 15000,
        avgLikes: 30,
        avgComments: 2,
        accountAge: 45,
        followerToFollowingRatio: 150
      }
    },
    equipment: [],
    pricing: 0,
    availability: [],
    appliedDate: '2025-04-08',
    status: 'pending',
    reports: 2,
    reportedBy: 'User #42',
    reportReason: 'Fake profile suspected',
    reportDate: '2025-04-12',
    previousRejections: 2,
    applicationCount: 4,
    emailDomain: 'mailinator.com',
    applicationSpeed: 25
  },

  // ============================================
  // DJ 3: Already verified — legit pro
  // ============================================
  {
    id: 3,
    name: 'DJ Melody',
    email: 'melody@email.com',
    phone: '+27 63 456 7890',
    type: 'dj',
    genre: 'Afro Tech',
    genres: ['Afro Tech', 'Deep House', 'Techno'],
    location: 'Pretoria East',
    experience: 4,
    bio: 'Afro Tech specialist with 4 years of experience. Regular at Sunday rooftop sessions and private functions. My sets blend soulful melodies with driving rhythms. Book me for your next event.',
    portfolioUrl: 'https://soundcloud.com/melody-za',
    idDocument: 'id_melody.pdf',
    idNumber: '9505127890084',
    idName: 'Melody Ndlovu',
    fullName: 'Melody Ndlovu',
    profilePhoto: 'profile_melody.jpg',
    idPhoto: 'id_photo_melody.jpg',
    dateOfBirth: '1995-05-12',
    mixCount: 12,
    avgMixDuration: 2400,
    avgBitrate: 320,
    hasLiveSets: true,
    hasTracklists: true,
    livenessVerified: true,
    socialLinks: {
      instagram: {
        followers: 5600,
        avgLikes: 350,
        avgComments: 45,
        accountAge: 600,
        followerToFollowingRatio: 1.2
      },
      soundcloud: {
        followers: 2800,
        avgLikes: 120,
        avgComments: 30,
        accountAge: 500,
        followerToFollowingRatio: 1.0
      }
    },
    equipment: ['Pioneer XDJ-XZ', 'Laptop', 'Monitor Speakers'],
    pricing: 3500,
    bankDetails: { bankName: 'Capitec', accountHolder: 'Melody Dlamini', accountNumber: '1487523690', branchCode: '470010' },
    availability: ['weekends', 'evenings', 'weekdays'],
    appliedDate: '2025-04-05',
    status: 'verified',
    reports: 0,
    previousRejections: 0,
    applicationCount: 1,
    emailDomain: 'email.com',
    applicationSpeed: 180
  },

  // ============================================
  // PHOTOGRAPHER: Good portfolio, needs review
  // ============================================
  {
    id: 4,
    name: 'Lebo P.',
    email: 'lebo@email.com',
    phone: '+27 84 567 8901',
    type: 'photographer',
    genre: 'Events',
    genres: ['Events', 'Portraits', 'Fashion'],
    location: 'Cape Town CBD',
    experience: 2,
    bio: 'Event and portrait photographer based in Cape Town. I capture moments that tell stories. Available for weddings, corporate events, and creative shoots.',
    portfolioUrl: 'https://instagram.com/lebophotos',
    idDocument: 'id_lebo.pdf',
    idNumber: '9708084567089',
    idName: 'Lebohang Peters',
    fullName: 'Lebohang Peters',
    profilePhoto: 'profile_lebo.jpg',
    idPhoto: 'id_photo_lebo.jpg',
    dateOfBirth: '1997-08-08',
    galleryCount: 25,
    avgImageResolution: 2400,
    hasBeforeAfter: true,
    styles: ['Events', 'Portraits', 'Fashion', 'Black & White'],
    hasShowreel: false,
    videoCount: 0,
    avgVideoDuration: 0,
    videoQuality: 0,
    socialLinks: {
      instagram: {
        followers: 1800,
        avgLikes: 120,
        avgComments: 35,
        accountAge: 450,
        followerToFollowingRatio: 1.8
      }
    },
    equipment: ['Canon EOS R6', '24-70mm f/2.8', 'Speedlite Flash'],
    pricing: 3000,
    bankDetails: { bankName: 'Standard Bank', accountHolder: 'Lebo Phiri', accountNumber: '331245678', branchCode: '051001' },
    availability: ['weekends', 'weekdays'],
    appliedDate: '2025-04-03',
    status: 'pending',
    reports: 0,
    previousRejections: 0,
    applicationCount: 1,
    emailDomain: 'email.com',
    applicationSpeed: 240,
    rejectionReason: null
  },

  // ============================================
  // MC: Newcomer, limited portfolio but genuine
  // ============================================
  {
    id: 5,
    name: 'Thando M.',
    email: 'thando@email.com',
    phone: '+27 79 123 4567',
    type: 'mc',
    genre: 'Events',
    genres: ['Events', 'Weddings', 'Corporate'],
    location: 'Soweto, Johannesburg',
    experience: 1,
    bio: 'Upcoming MC bringing energy to every event. I love connecting with audiences and making every moment memorable. Available for parties, weddings, and corporate functions.',
    portfolioUrl: 'https://youtube.com/@thandomc',
    idDocument: 'id_thando.pdf',
    idNumber: '0002151234081',
    idName: 'Thando Mokoena',
    fullName: 'Thando Mokoena',
    profilePhoto: 'profile_thando.jpg',
    idPhoto: 'id_photo_thando.jpg',
    dateOfBirth: '2000-02-15',
    hasVideo: true,
    hasEventRecordings: true,
    languages: ['English', 'Zulu', 'Sotho'],
    mixCount: 0,
    avgMixDuration: 0,
    avgBitrate: 0,
    galleryCount: 0,
    avgImageResolution: 0,
    styles: [],
    socialLinks: {
      tiktok: {
        followers: 450,
        avgLikes: 85,
        avgComments: 22,
        accountAge: 200,
        followerToFollowingRatio: 1.1
      },
      instagram: {
        followers: 320,
        avgLikes: 45,
        avgComments: 18,
        accountAge: 180,
        followerToFollowingRatio: 1.3
      }
    },
    equipment: ['Wireless Microphone', 'Portable Speaker'],
    pricing: 1500,
    bankDetails: { bankName: 'Nedbank', accountHolder: 'Thando Mokoena', accountNumber: '1123456789', branchCode: '198765' },
    availability: ['weekends', 'evenings'],
    appliedDate: '2025-04-11',
    status: 'pending',
    reports: 0,
    previousRejections: 0,
    applicationCount: 1,
    emailDomain: 'gmail.com',
    applicationSpeed: 150
  }
];


let currentPage = 'dashboard';
let pendingAction = null;
let pendingPayoutBookingRef = null;

// ---------- SAMPLE BOOKINGS (so the Payments page isn't empty before anyone uses booking.html) ----------
// Real bookings made through booking.html get merged in from localStorage — see loadBookings() below.
let sampleBookings = [
  {
    ref: 'GIGZA-SAMPLE-001',
    djId: 3, djName: 'DJ Melody',
    clientName: 'Naledi Mokoena', clientEmail: 'naledi@example.com', clientPhone: '083 555 1122',
    eventType: 'Wedding', eventDate: '2025-06-14', eventLocation: 'Rosebank, Johannesburg',
    djRate: 3500, serviceFee: 350, total: 3850,
    paymentStatus: 'paid', paymentMethod: 'payfast',
    payoutStatus: 'paid', payoutAmount: 3500, payoutRef: 'CAP-EFT-8821', payoutDate: '2025-06-16T09:00:00.000Z',
    createdAt: '2025-06-01T10:00:00.000Z', paidAt: '2025-06-01T10:03:00.000Z'
  },
  {
    ref: 'GIGZA-SAMPLE-002',
    djId: 1, djName: 'DJ Zee',
    clientName: 'Sipho Dube', clientEmail: 'sipho@example.com', clientPhone: '071 222 3344',
    eventType: 'Birthday party', eventDate: '2025-07-02', eventLocation: 'Sandton, Johannesburg',
    djRate: 2500, serviceFee: 250, total: 2750,
    paymentStatus: 'paid', paymentMethod: 'payfast',
    payoutStatus: 'due', payoutAmount: 2500, payoutRef: null, payoutDate: null,
    createdAt: '2025-06-20T14:00:00.000Z', paidAt: '2025-06-20T14:02:00.000Z'
  },
  {
    ref: 'GIGZA-SAMPLE-003',
    djId: 4, djName: 'Lebo P.',
    clientName: 'Aisha Patel', clientEmail: 'aisha@example.com', clientPhone: '084 777 9900',
    eventType: 'Corporate event', eventDate: '2025-07-20', eventLocation: 'Midrand',
    djRate: 3000, serviceFee: 300, total: 3300,
    paymentStatus: 'pending', paymentMethod: 'payfast',
    payoutStatus: 'not_due', payoutAmount: 3000, payoutRef: null, payoutDate: null,
    createdAt: '2025-07-10T08:30:00.000Z', paidAt: null
  }
];

// ---------- ADD A NEW APPLICATION (runs it through the AI verification engine) ----------
// Call this whenever a new DJ/creative applies — e.g. once you have a real signup API,
// call addNewCreative(dataFromApi) when the applicant submits their form.
async function addNewCreative(creativeData) {
  // Give it a real unique id so buttons/lookups for this DJ work correctly.
  const nextId = djs.length > 0 ? Math.max(...djs.map(d => d.id)) + 1 : 1;
  creativeData.id = nextId;
  creativeData.status = creativeData.status || 'pending';
  creativeData.reports = creativeData.reports || 0;

  // Run the AI checks (see ai-verification.js)
  const result = await verificationEngine.verifyCreative(creativeData);

  // Store the results on the record so the DJ card and details modal can show them
  creativeData.aiConfidence = result.confidence;
  creativeData.aiScores = result.scores;
  creativeData.aiFlags = result.flags;
  creativeData.aiReviewTips = result.reviewTips;
  creativeData.aiOutcome = result.outcome;
  creativeData.requiresAdmin = result.outcome.requiresAdmin;
  creativeData.autoVerified = !result.outcome.requiresAdmin;

  // If the AI engine says this is a clear auto-approve, mark it verified right away.
  // Otherwise it stays 'pending' so an admin reviews it.
  if (result.outcome.status === 'approved') {
    creativeData.status = 'verified';
  }

  djs.push(creativeData);
  renderAll();
  return result;
}

// Run any DJ record that hasn't been scored yet through the AI verification engine.
// This covers the hardcoded sample data below (which is added directly to the djs
// array, not through addNewCreative) so the AI badges/flags show up for them too.
// It only adds the score — it does NOT change their existing status, since the
// sample data's statuses (pending/verified/rejected) are set on purpose for the demo.
async function scoreExistingDJs() {
  for (const dj of djs) {
    if (typeof dj.aiConfidence !== 'number') {
      try {
        const result = await verificationEngine.verifyCreative(dj);
        dj.aiConfidence = result.confidence;
        dj.aiScores = result.scores;
        dj.aiFlags = result.flags;
        dj.aiReviewTips = result.reviewTips;
        dj.aiOutcome = result.outcome;
        dj.requiresAdmin = result.outcome.requiresAdmin;
      } catch (e) {
        // Don't let one bad record take down the whole page — log it and move on.
        console.error(`⚠️ AI scoring failed for ${dj.name}:`, e);
      }
    }
  }
}

document.addEventListener('DOMContentLoaded', async () => {
  initNavigation();
  initSearch();
  initMobileMenu();

  if (typeof verificationEngine === 'undefined' || !verificationEngine) {
    console.error('⚠️ verificationEngine is not defined — check that ai-verification.js is in the same folder as admin.html and loaded BEFORE admin.js in the <script> tags.');
  } else {
    await scoreExistingDJs();
  }

  renderAll();

  document.getElementById('confirmRejectBtn').addEventListener('click', confirmRejection);
  document.getElementById('confirmPayoutBtn').addEventListener('click', confirmPayout);
  console.log('🎛️ GIGZA Admin Panel Ready');
  console.log('🤖 AI verification engine ran on sample data — check the AI badges + notes on each card');
  console.log('📡 Sample data loaded — replace with API calls in admin.js');
});
function initNavigation() {
  document.querySelectorAll('.nav-item').forEach(item => {
    item.addEventListener('click', (e) => {
      e.preventDefault();
      const page = item.dataset.page;
      navigateTo(page);
    });
  });
}

function navigateTo(page) {
  currentPage = page;
  
  // This updates nav
  document.querySelectorAll('.nav-item').forEach(item => {
    item.classList.toggle('active', item.dataset.page === page);
  });
  
  // This updates pages
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.getElementById(`${page}-page`)?.classList.add('active');
  document.getElementById('sidebar').classList.remove('open');
  renderPage(page);
}

function initMobileMenu() {
  document.getElementById('menuToggle').addEventListener('click', () => {
    document.getElementById('sidebar').classList.toggle('open');
  });
 
  document.addEventListener('click', (e) => {
    const sidebar = document.getElementById('sidebar');
    const toggle = document.getElementById('menuToggle');
    if (!sidebar.contains(e.target) && !toggle.contains(e.target)) {
      sidebar.classList.remove('open');
    }
  });
}

function initSearch() {
  const searchPending = document.getElementById('searchPending');
  const searchVerified = document.getElementById('searchVerified');
  const filterGenre = document.getElementById('filterGenre');
  
  if (searchPending) {
    searchPending.addEventListener('input', () => renderPendingDJs());
  }
  if (searchVerified) {
    searchVerified.addEventListener('input', () => renderVerifiedDJs());
  }
  if (filterGenre) {
    filterGenre.addEventListener('change', () => renderPendingDJs());
  }

  const searchPayments = document.getElementById('searchPayments');
  const filterPayoutStatus = document.getElementById('filterPayoutStatus');
  if (searchPayments) {
    searchPayments.addEventListener('input', () => renderPayments());
  }
  if (filterPayoutStatus) {
    filterPayoutStatus.addEventListener('change', () => renderPayments());
  }
}

function getFilteredDJs(status) {
  let filtered = djs.filter(dj => dj.status === status);
  
  if (status === 'pending') {
    const searchTerm = document.getElementById('searchPending')?.value.toLowerCase() || '';
    const genreFilter = document.getElementById('filterGenre')?.value || '';
    
    if (searchTerm) {
      filtered = filtered.filter(dj => 
        dj.name.toLowerCase().includes(searchTerm) ||
        dj.location.toLowerCase().includes(searchTerm) ||
        dj.genre.toLowerCase().includes(searchTerm)
      );
    }
    if (genreFilter) {
      filtered = filtered.filter(dj => dj.genre.toLowerCase() === genreFilter.toLowerCase());
    }
  }
  
  if (status === 'verified') {
    const searchTerm = document.getElementById('searchVerified')?.value.toLowerCase() || '';
    if (searchTerm) {
      filtered = filtered.filter(dj => 
        dj.name.toLowerCase().includes(searchTerm) ||
        dj.location.toLowerCase().includes(searchTerm) ||
        dj.genre.toLowerCase().includes(searchTerm)
      );
    }
  }
  
  return filtered;
}

function renderAll() {
  updateStats();
  renderRecentApplications();
  renderPendingDJs();
  renderVerifiedDJs();
  renderRejectedDJs();
  renderReportedDJs();
  renderPayments();
}

function renderPage(page) {
  switch(page) {
    case 'dashboard':
      updateStats();
      renderRecentApplications();
      break;
    case 'pending':
      renderPendingDJs();
      break;
    case 'verified':
      renderVerifiedDJs();
      break;
    case 'rejected':
      renderRejectedDJs();
      break;
    case 'reported':
      renderReportedDJs();
      break;
    case 'payments':
      renderPayments();
      break;
  }
}

function updateStats() {
  const pending = djs.filter(dj => dj.status === 'pending').length;
  const verified = djs.filter(dj => dj.status === 'verified').length;
  const rejected = djs.filter(dj => dj.status === 'rejected').length;
  const reported = djs.filter(dj => dj.reports > 0).length;
  
  document.getElementById('statPending').textContent = pending;
  document.getElementById('statVerified').textContent = verified;
  document.getElementById('statRejected').textContent = rejected;
  document.getElementById('statReported').textContent = reported;
  
  const pendingCountEl = document.getElementById('pendingCount');
  if (pendingCountEl) {
    pendingCountEl.textContent = pending;
    pendingCountEl.style.display = pending > 0 ? 'inline' : 'none';
  }
}

function renderRecentApplications() {
  const tbody = document.getElementById('recentApplications');
  const recent = [...djs]
    .sort((a, b) => new Date(b.appliedDate) - new Date(a.appliedDate))
    .slice(0, 5);
  
  if (recent.length === 0) {
    tbody.innerHTML = `
      <tr class="empty-row">
        <td colspan="6">
          <div class="empty-state-inline">
            <i class="fas fa-inbox"></i>
            <p>No applications yet</p>
          </div>
        </td>
      </tr>`;
    return;
  }
  tbody.innerHTML = recent.map(dj => `
    <tr>
      <td><strong>${escapeHtml(dj.name)}</strong></td>
      <td>${escapeHtml(dj.genre)}</td>
      <td>${escapeHtml(dj.location)}</td>
      <td>${formatDate(dj.appliedDate)}</td>
      <td><span class="status-badge ${dj.status}">${escapeHtml(dj.status)}</span></td>
      <td>
        <button class="btn btn-sm btn-view" onclick="viewDJ(${dj.id})">
          <i class="fas fa-eye"></i> View
        </button>
      </td>
    </tr>
  `).join('');
}

//  Pending DJs
function renderPendingDJs() {
  const grid = document.getElementById('pendingGrid');
  const pending = getFilteredDJs('pending');
  
  if (pending.length === 0) {
    grid.innerHTML = `
      <div class="empty-state">
        <i class="fas fa-inbox"></i>
        <p>No pending applications</p>
        <span>New DJ applications will appear here for review</span>
      </div>`;
    return;
  }
  
  grid.innerHTML = pending.map(dj => createDJCard(dj)).join('');
  pending.forEach(dj => {
    const card = document.getElementById(`dj-card-${dj.id}`);
    if (card) {
      card.querySelector('.btn-approve')?.addEventListener('click', () => confirmAction('approve', dj.id));
      card.querySelector('.btn-reject')?.addEventListener('click', () => confirmAction('reject', dj.id));
      card.querySelector('.btn-view')?.addEventListener('click', () => viewDJ(dj.id));
      card.querySelector('.btn-run-ai')?.addEventListener('click', () => runAICheck(dj.id));
    }
  });
}
// ---------- REJECTION REASON MODAL ----------
let pendingRejectDJ = null;

function openRejectReasonModal(djId) {
  const dj = djs.find(d => d.id === djId);
  if (!dj) return;
  
  pendingRejectDJ = dj;
  document.getElementById('rejectDJName').textContent = dj.name;
  document.getElementById('rejectReasonSelect').value = '';
  
  const otherGroup = document.getElementById('otherReasonGroup');
  if (otherGroup) otherGroup.style.display = 'none';
  
  const otherText = document.getElementById('otherReasonText');
  if (otherText) otherText.value = '';
  
  openModal('rejectReasonModal');
}

function handleReasonChange() {
  const select = document.getElementById('rejectReasonSelect');
  const otherGroup = document.getElementById('otherReasonGroup');
  if (select && otherGroup) {
    otherGroup.style.display = select.value === 'other' ? 'block' : 'none';
  }
}

function confirmRejection() {
  const select = document.getElementById('rejectReasonSelect');
  const otherText = document.getElementById('otherReasonText');
  
  if (!select) return;
  
  let reason = select.value;
  
  if (!reason) {
    alert('Please select a reason for rejection.');
    return;
  }
  
  if (reason === 'other') {
    if (!otherText || !otherText.value.trim()) {
      alert('Please specify the rejection reason.');
      return;
    }
    reason = otherText.value.trim();
  }
  
  if (!pendingRejectDJ) return;
  
  pendingRejectDJ.status = 'rejected';
  pendingRejectDJ.rejectionReason = reason;
  
  showToast(`${pendingRejectDJ.name} rejected: ${reason}`, 'error');
  
  closeModal('rejectReasonModal');
  pendingRejectDJ = null;
  renderAll();
}
// Veriefied DJs
function renderVerifiedDJs() {
  const grid = document.getElementById('verifiedGrid');
  const verified = getFilteredDJs('verified');
  
  if (verified.length === 0) {
    grid.innerHTML = `
      <div class="empty-state">
        <i class="fas fa-users"></i>
        <p>No verified DJs yet</p>
        <span>Approved DJs will appear here</span>
      </div>`;
    return;
  }
  
  grid.innerHTML = verified.map(dj => createDJCard(dj, true)).join('');
  
  verified.forEach(dj => {
    const card = document.getElementById(`dj-card-${dj.id}`);
    if (card) {
      card.querySelector('.btn-view')?.addEventListener('click', () => viewDJ(dj.id));
      card.querySelector('.btn-remove')?.addEventListener('click', () => confirmAction('remove', dj.id));
    }
  });
}

//  Rejected DJs 
function renderRejectedDJs() {
  const tbody = document.getElementById('rejectedTable');
  const rejected = djs.filter(dj => dj.status === 'rejected');
  
  if (rejected.length === 0) {
    tbody.innerHTML = `
      <tr class="empty-row">
        <td colspan="5">
          <div class="empty-state-inline">
            <i class="fas fa-times-circle"></i>
            <p>No rejected applications</p>
          </div>
        </td>
      </tr>`;
    return;
  }
  
  tbody.innerHTML = rejected.map(dj => `
    <tr>
      <td><strong>${escapeHtml(dj.name)}</strong></td>
      <td>${escapeHtml(dj.genre)}</td>
      <td>${escapeHtml(dj.rejectionReason || 'Application rejected')}</td>
      <td>${formatDate(dj.appliedDate)}</td>
      <td>
        <button class="btn btn-sm btn-view" onclick="viewDJ(${dj.id})">
          <i class="fas fa-eye"></i> View
        </button>
        <button class="btn btn-sm btn-approve" onclick="confirmAction('approve', ${dj.id})" style="margin-left: 6px;">
          <i class="fas fa-undo"></i> Reconsider
        </button>
      </td>
    </tr>
  `).join('');
}

// Reported DJs 
function renderReportedDJs() {
  const tbody = document.getElementById('reportedTable');
  const reported = djs.filter(dj => dj.reports > 0);
  
  if (reported.length === 0) {
    tbody.innerHTML = `
      <tr class="empty-row">
        <td colspan="5">
          <div class="empty-state-inline">
            <i class="fas fa-flag"></i>
            <p>No reported DJs</p>
          </div>
        </td>
      </tr>`;
    return;
  }
  
  tbody.innerHTML = reported.map(dj => `
    <tr>
      <td><strong>${escapeHtml(dj.name)}</strong></td>
      <td>
        <span class="status-badge rejected" style="font-size: 0.7rem;">${dj.reports} report${dj.reports > 1 ? 's' : ''}</span>
      </td>
      <td>${escapeHtml(dj.reportedBy || 'Unknown')}</td>
      <td>${escapeHtml(dj.reportReason || 'Violation reported')}</td>
      <td>
        <button class="btn btn-sm btn-view" onclick="viewDJ(${dj.id})">
          <i class="fas fa-eye"></i>
        </button>
        <button class="btn btn-sm btn-approve" onclick="confirmAction('clear-report', ${dj.id})" style="margin-left: 6px;">
          <i class="fas fa-check"></i> Clear
        </button>
        <button class="btn btn-sm btn-reject" onclick="confirmAction('remove', ${dj.id})" style="margin-left: 6px;">
          <i class="fas fa-ban"></i> Remove
        </button>
      </td>
    </tr>
  `).join('');
}

// =============================================
// PAYMENTS
// =============================================

// Real bookings made on booking.html are saved to localStorage (see booking.js).
// Here we read those and merge them with the sample bookings above, so this page
// shows both. In production, this would be a fetch() to your bookings API instead.
function loadBookings() {
  let stored = [];
  try {
    const raw = localStorage.getItem('gigza_bookings');
    stored = raw ? JSON.parse(raw) : [];
  } catch (e) {
    console.error('Could not read bookings from storage:', e);
  }
  // Sample bookings first, then real ones from the booking page, newest first
  return [...sampleBookings, ...stored].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
}

function saveBookingUpdate(ref, changes) {
  // Sample bookings live only in memory (editing them just updates sampleBookings).
  // Real bookings live in localStorage and need to be written back there.
  const sampleIndex = sampleBookings.findIndex(b => b.ref === ref);
  if (sampleIndex !== -1) {
    Object.assign(sampleBookings[sampleIndex], changes);
    return;
  }
  try {
    const raw = localStorage.getItem('gigza_bookings');
    const stored = raw ? JSON.parse(raw) : [];
    const idx = stored.findIndex(b => b.ref === ref);
    if (idx !== -1) {
      Object.assign(stored[idx], changes);
      localStorage.setItem('gigza_bookings', JSON.stringify(stored));
    }
  } catch (e) {
    console.error('Could not update booking in storage:', e);
  }
}

function getFilteredBookings() {
  let filtered = loadBookings();

  const searchTerm = document.getElementById('searchPayments')?.value.toLowerCase() || '';
  const payoutFilter = document.getElementById('filterPayoutStatus')?.value || '';

  if (searchTerm) {
    filtered = filtered.filter(b =>
      b.clientName.toLowerCase().includes(searchTerm) ||
      b.djName.toLowerCase().includes(searchTerm) ||
      b.ref.toLowerCase().includes(searchTerm)
    );
  }
  if (payoutFilter) {
    filtered = filtered.filter(b => b.payoutStatus === payoutFilter);
  }

  return filtered;
}

function formatCurrency(amount) {
  return 'R' + Number(amount || 0).toLocaleString('en-ZA');
}

function updatePaymentStats() {
  const all = loadBookings();
  const paid = all.filter(b => b.paymentStatus === 'paid');

  const collected = paid.reduce((sum, b) => sum + Number(b.total || 0), 0);
  const owed = paid.filter(b => b.payoutStatus === 'due').reduce((sum, b) => sum + Number(b.payoutAmount || 0), 0);
  const paidOut = paid.filter(b => b.payoutStatus === 'paid').reduce((sum, b) => sum + Number(b.payoutAmount || 0), 0);
  const commission = paid.reduce((sum, b) => sum + Number(b.serviceFee || 0), 0);

  const statCollected = document.getElementById('statCollected');
  const statPayoutsDue = document.getElementById('statPayoutsDue');
  const statPaidOut = document.getElementById('statPaidOut');
  const statCommission = document.getElementById('statCommission');
  if (statCollected) statCollected.textContent = formatCurrency(collected);
  if (statPayoutsDue) statPayoutsDue.textContent = formatCurrency(owed);
  if (statPaidOut) statPaidOut.textContent = formatCurrency(paidOut);
  if (statCommission) statCommission.textContent = formatCurrency(commission);

  const dueCount = paid.filter(b => b.payoutStatus === 'due').length;
  const payoutsDueCountEl = document.getElementById('payoutsDueCount');
  if (payoutsDueCountEl) {
    payoutsDueCountEl.textContent = dueCount;
    payoutsDueCountEl.style.display = dueCount > 0 ? 'inline' : 'none';
  }
}

const PAYMENT_STATUS_LABELS = { paid: 'Paid', pending: 'Awaiting payment', failed: 'Failed / cancelled' };
const PAYOUT_STATUS_LABELS = { due: 'Payout due', paid: 'Paid out', not_due: 'Not due yet' };
// Reuse the existing status-badge color classes (pending=orange, verified=green, rejected=red)
// rather than inventing new CSS — 'not_due' just gets no color treatment.
const PAYMENT_STATUS_CLASS = { paid: 'verified', pending: 'pending', failed: 'rejected' };
const PAYOUT_STATUS_CLASS = { due: 'pending', paid: 'verified', not_due: '' };

function renderPayments() {
  const tbody = document.getElementById('paymentsTable');
  if (!tbody) return;

  updatePaymentStats();
  const bookings = getFilteredBookings();

  if (bookings.length === 0) {
    tbody.innerHTML = `
      <tr class="empty-row">
        <td colspan="9">
          <div class="empty-state-inline">
            <i class="fas fa-money-bill-wave"></i>
            <p>No bookings found</p>
          </div>
        </td>
      </tr>`;
    return;
  }

  tbody.innerHTML = bookings.map(b => `
    <tr>
      <td><strong>${escapeHtml(b.ref)}</strong></td>
      <td>${escapeHtml(b.clientName)}</td>
      <td>${escapeHtml(b.djName)}</td>
      <td>${formatDate(b.eventDate)}</td>
      <td>${formatCurrency(b.total)}</td>
      <td>${formatCurrency(b.payoutAmount)}</td>
      <td><span class="status-badge ${PAYMENT_STATUS_CLASS[b.paymentStatus] || ''}">${escapeHtml(PAYMENT_STATUS_LABELS[b.paymentStatus] || b.paymentStatus)}</span></td>
      <td><span class="status-badge ${PAYOUT_STATUS_CLASS[b.payoutStatus] || ''}">${escapeHtml(PAYOUT_STATUS_LABELS[b.payoutStatus] || b.payoutStatus)}</span></td>
      <td>
        ${b.payoutStatus === 'due'
          ? `<button class="btn btn-sm btn-approve" onclick="openPayoutModal('${escapeHtml(b.ref)}')"><i class="fas fa-hand-holding-dollar"></i> Pay Out</button>`
          : b.payoutStatus === 'paid'
            ? `<span style="font-size:0.78rem; color: var(--text-muted);"><i class="fas fa-check"></i> Ref: ${escapeHtml(b.payoutRef || 'n/a')}</span>`
            : `<span style="font-size:0.78rem; color: var(--text-muted);">Awaiting payment</span>`
        }
      </td>
    </tr>
  `).join('');
}

function openPayoutModal(ref) {
  const booking = loadBookings().find(b => b.ref === ref);
  if (!booking) return;

  pendingPayoutBookingRef = ref;
  const dj = djs.find(d => d.id === booking.djId);

  document.getElementById('payoutDJName').textContent = booking.djName;
  document.getElementById('payoutBookingRef').textContent = booking.ref;
  document.getElementById('payoutAmountDisplay').textContent = formatCurrency(booking.payoutAmount);
  document.getElementById('payoutRefInput').value = '';

  const bankEl = document.getElementById('payoutBankDetails');
  if (dj && dj.bankDetails) {
    const bd = dj.bankDetails;
    bankEl.innerHTML = `
      <div class="detail-row">
        <i class="fas fa-building-columns"></i>
        <span><strong>Bank:</strong> ${escapeHtml(bd.bankName)} &nbsp;•&nbsp;
        <strong>Account holder:</strong> ${escapeHtml(bd.accountHolder)}<br>
        <strong>Account no:</strong> ${escapeHtml(bd.accountNumber)} &nbsp;•&nbsp;
        <strong>Branch code:</strong> ${escapeHtml(bd.branchCode)}</span>
      </div>`;
  } else {
    bankEl.innerHTML = `<p style="color: var(--danger-red); font-size: 0.85rem; margin-top: 0.5rem;">
      ⚠️ No bank details on file for this DJ yet. Get their banking details before paying out.
    </p>`;
  }

  openModal('payoutModal');
}

function confirmPayout() {
  if (!pendingPayoutBookingRef) return;
  const refInput = document.getElementById('payoutRefInput').value.trim();

  if (!refInput) {
    showToast('Please enter a payment reference before confirming.', 'error');
    return;
  }

  saveBookingUpdate(pendingPayoutBookingRef, {
    payoutStatus: 'paid',
    payoutRef: refInput,
    payoutDate: new Date().toISOString()
  });

  closeModal('payoutModal');
  showToast('Payout recorded.');
  renderPayments();
  pendingPayoutBookingRef = null;
}

function createDJCard(dj, isVerified = false) {
  const initials = dj.name.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase();

  // Show the AI confidence score as a small badge, if this DJ has been through
  // the verification engine (see addNewCreative). Older/sample records that
  // never ran through it just won't show a badge.
  let aiBadge = '';
  if (typeof dj.aiConfidence === 'number') {
    let badgeColor = 'var(--danger-red)';
    if (dj.aiConfidence >= 75) badgeColor = 'var(--success-green)';
    else if (dj.aiConfidence >= 55) badgeColor = 'var(--cyber-blue)';
    else if (dj.aiConfidence >= 30) badgeColor = 'var(--warning-orange)';
    aiBadge = `<span class="dj-tag" style="color:${badgeColor}; border-color:${badgeColor};"><i class="fas fa-robot"></i> AI: ${dj.aiConfidence}%</span>`;
  }

  // Show the top 1-2 AI review tips directly on the card — the whole point of
  // these notes is for an admin to see them while scanning the list, not have
  // to click into every single profile first.
  let aiNotesPreview = '';
  if (dj.aiReviewTips && dj.aiReviewTips.length > 0) {
    const topTips = dj.aiReviewTips.slice(0, 2);
    aiNotesPreview = `
      <div class="dj-ai-notes">
        <strong><i class="fas fa-robot"></i> AI notes:</strong>
        <ul>
          ${topTips.map(t => `<li>${t.icon} ${escapeHtml(t.text)}</li>`).join('')}
        </ul>
        ${dj.aiReviewTips.length > 2 ? `<span class="dj-ai-notes-more">+${dj.aiReviewTips.length - 2} more, click View Details</span>` : ''}
      </div>`;
  }

  return `
    <div class="dj-card" id="dj-card-${dj.id}">
      <div class="dj-card-header">
        <div class="dj-avatar">${escapeHtml(initials)}</div>
        <div class="dj-card-info">
          <h4>${escapeHtml(dj.name)}</h4>
          <span>Applied ${formatDate(dj.appliedDate)}</span>
        </div>
      </div>
      <div class="dj-card-details">
        <span class="dj-tag"><i class="fas fa-music"></i> ${escapeHtml(dj.genre)}</span>
        <span class="dj-tag"><i class="fas fa-map-marker-alt"></i> ${escapeHtml(dj.location)}</span>
        <span class="dj-tag"><i class="fas fa-briefcase"></i> ${escapeHtml(dj.experience)}</span>
        ${dj.reports > 0 ? `<span class="dj-tag warning"><i class="fas fa-flag"></i> ${dj.reports} report${dj.reports > 1 ? 's' : ''}</span>` : ''}
        ${aiBadge}
      </div>
      ${aiNotesPreview}
      <div class="dj-card-actions">
        ${isVerified ? `
          <button class="btn btn-sm btn-view">
            <i class="fas fa-eye"></i> View Profile
          </button>
          <button class="btn btn-sm btn-reject btn-remove">
            <i class="fas fa-user-slash"></i> Remove
          </button>
        ` : `
          <button class="btn btn-sm btn-view">
            <i class="fas fa-eye"></i> View Details
          </button>
          <button class="btn btn-sm btn-run-ai" id="run-ai-btn-${dj.id}">
            <i class="fas fa-robot"></i> ${typeof dj.aiConfidence === 'number' ? 'Re-run AI' : 'Run AI Check'}
          </button>
          <button class="btn btn-sm btn-approve">
            <i class="fas fa-check"></i> Approve
          </button>
          <button class="btn btn-sm btn-reject">
            <i class="fas fa-times"></i> Reject
          </button>
        `}
      </div>
    </div>
  `;
}
// ---------- RUN / RE-RUN AI CHECK ON DEMAND ----------
// Called from the "Run AI Check" button on a pending card, or the matching
// button inside the details modal.
//   - From a card: re-scores the DJ, then makes the notes box on that card
//     visibly pop into view (scrolls to it + a brief highlight animation)
//     instead of yanking the admin into a separate modal.
//   - From inside the modal (fromModal = true): refreshes the modal in place.
async function runAICheck(djId, fromModal = false) {
  const dj = djs.find(d => d.id === djId);
  if (!dj) return;

  // Show a loading state on whichever button was clicked (card and/or modal
  // versions might both exist in the DOM — update both if present).
  const cardBtn = document.getElementById(`run-ai-btn-${djId}`);
  const modalBtn = document.getElementById('modalRunAiBtn');
  [cardBtn, modalBtn].forEach(btn => {
    if (btn) {
      btn.disabled = true;
      btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Running AI check...';
    }
  });

  try {
    const result = await verificationEngine.verifyCreative(dj);
    dj.aiConfidence = result.confidence;
    dj.aiScores = result.scores;
    dj.aiFlags = result.flags;
    dj.aiReviewTips = result.reviewTips;
    dj.aiOutcome = result.outcome;
    dj.requiresAdmin = result.outcome.requiresAdmin;

    showToast(`AI check complete for ${dj.name}: ${result.confidence}% (${result.outcome.message})`, result.outcome.status === 'full_review' ? 'error' : 'success');

    if (fromModal) {
      viewDJ(djId); // refreshes the modal in place with the new score, flags, and tips
    } else {
      renderPendingDJs(); // rebuilds the card with the fresh notes already in its HTML
      popAiNotesIntoView(djId);
    }
  } catch (e) {
    console.error('AI check failed:', e);
    showToast('AI check failed. Please try again.', 'error');
    [cardBtn, modalBtn].forEach(btn => {
      if (btn) {
        btn.disabled = false;
        btn.innerHTML = '<i class="fas fa-robot"></i> Run AI Check';
      }
    });
  }
}

// Scrolls the DJ's card into view and briefly highlights its AI notes box,
// so a fresh "Run AI Check" result is obviously visible instead of silently
// updating somewhere off-screen.
function popAiNotesIntoView(djId) {
  const card = document.getElementById(`dj-card-${djId}`);
  if (!card) return;

  card.scrollIntoView({ behavior: 'smooth', block: 'center' });

  const notesBox = card.querySelector('.dj-ai-notes');
  if (notesBox) {
    notesBox.classList.remove('ai-notes-pop'); // reset in case it's already mid-animation
    void notesBox.offsetWidth; // force reflow so the animation restarts
    notesBox.classList.add('ai-notes-pop');
  }
}

function viewDJ(djId) {
  const dj = djs.find(d => d.id === djId);
  if (!dj) return;
  
  document.getElementById('modalDJName').textContent = dj.name;

  const portfolioLink = safeUrl(dj.portfolioUrl);

  // Build the AI verification section, only if this DJ has actually been
  // through the verification engine (see addNewCreative / aiConfidence).
  let aiSectionHTML = '';
  if (typeof dj.aiConfidence === 'number') {
    const flagsHTML = (dj.aiFlags && dj.aiFlags.length > 0)
      ? dj.aiFlags.map(f => `
          <div class="detail-row" style="align-items:flex-start;">
            <span>${f.icon || '⚑'}</span>
            <span><strong>${escapeHtml(f.message)}</strong><br>
              <span style="color:var(--text-gray); font-size:0.85rem;">${escapeHtml(f.detail)}</span>
            </span>
          </div>`).join('')
      : `<p style="color: var(--success-green);">No flags raised by the AI checks.</p>`;

    const tipsHTML = (dj.aiReviewTips && dj.aiReviewTips.length > 0)
      ? dj.aiReviewTips.map(t => `
          <div class="detail-row" style="align-items:flex-start;">
            <span>${t.icon || '💡'}</span>
            <span style="font-size:0.85rem; color:var(--text-gray);">${escapeHtml(t.text)}</span>
          </div>`).join('')
      : '';

    aiSectionHTML = `
      <h4>AI Verification</h4>
      <p><strong>Confidence Score:</strong> ${dj.aiConfidence}%
        ${dj.aiOutcome ? `<span class="status-badge" style="background:${dj.aiOutcome.color}22; color:${dj.aiOutcome.color};">${escapeHtml(dj.aiOutcome.message)}</span>` : ''}
      </p>
      ${flagsHTML}
      ${tipsHTML ? `<h4 style="margin-top:1rem;">What to look out for</h4>${tipsHTML}` : ''}
    `;
  }

  document.getElementById('modalBody').innerHTML = `
    <div class="detail-row">
      <i class="fas fa-envelope"></i>
      <span><strong>Email:</strong> ${escapeHtml(dj.email)}</span>
    </div>
    <div class="detail-row">
      <i class="fas fa-phone"></i>
      <span><strong>Phone:</strong> ${escapeHtml(dj.phone)}</span>
    </div>
    <div class="detail-row">
      <i class="fas fa-music"></i>
      <span><strong>Genre:</strong> ${escapeHtml(dj.genre)}</span>
    </div>
    <div class="detail-row">
      <i class="fas fa-map-marker-alt"></i>
      <span><strong>Location:</strong> ${escapeHtml(dj.location)}</span>
    </div>
    <div class="detail-row">
      <i class="fas fa-briefcase"></i>
      <span><strong>Experience:</strong> ${escapeHtml(dj.experience)}</span>
    </div>
    ${portfolioLink ? `
    <div class="detail-row">
      <i class="fas fa-link"></i>
      <span><strong>Portfolio:</strong> <a href="${portfolioLink}" target="_blank" rel="noopener noreferrer">${escapeHtml(dj.portfolioUrl)}</a></span>
    </div>` : ''}
    <h4>Bio</h4>
    <p>${escapeHtml(dj.bio)}</p>
    ${dj.idDocument ? `
      <h4>ID Document</h4>
      <p style="color: var(--success-green);">📄 ${escapeHtml(dj.idDocument)} (Uploaded)</p>
    ` : `
      <h4>ID Document</h4>
      <p style="color: var(--danger-red);">⚠️ No ID document uploaded. This is required for verification</p>
    `}
    ${aiSectionHTML}
    <div class="detail-row" style="margin-top: 0.5rem;">
      <button class="btn btn-sm btn-outline" id="modalRunAiBtn" onclick="runAICheck(${dj.id}, true)">
        <i class="fas fa-robot"></i> ${typeof dj.aiConfidence === 'number' ? 'Re-run AI Check' : 'Run AI Check'}
      </button>
    </div>
    <h4>Application Status</h4>
    <span class="status-badge ${dj.status}">${escapeHtml(dj.status)}</span>
    ${dj.rejectionReason ? `<p style="margin-top: 0.5rem; color: var(--text-gray);"><strong>Reason:</strong> ${escapeHtml(dj.rejectionReason)}</p>` : ''}
  `;

  let footerHTML = '<button class="btn btn-cancel" onclick="closeModal(\'detailsModal\')">Close</button>';
  
  if (dj.status === 'pending') {
    footerHTML += `
      <button class="btn btn-reject" onclick="closeModal('detailsModal'); confirmAction('reject', ${dj.id})">
        <i class="fas fa-times"></i> Reject
      </button>
      <button class="btn btn-approve" onclick="closeModal('detailsModal'); confirmAction('approve', ${dj.id})">
        <i class="fas fa-check"></i> Approve DJ
      </button>
    `;
  } else if (dj.status === 'verified') {
    footerHTML += `
      <button class="btn btn-reject" onclick="closeModal('detailsModal'); confirmAction('remove', ${dj.id})">
        <i class="fas fa-user-slash"></i> Remove DJ
      </button>
    `;
  } else if (dj.status === 'rejected') {
    footerHTML += `
      <button class="btn btn-approve" onclick="closeModal('detailsModal'); confirmAction('approve', ${dj.id})">
        <i class="fas fa-undo"></i> Reconsider
      </button>
    `;
  }
  
  document.getElementById('modalFooter').innerHTML = footerHTML;
  openModal('detailsModal');
}

// ---------- REJECTION REASON MODAL ----------


function confirmAction(action, djId) {
  const dj = djs.find(d => d.id === djId);
  if (!dj) return;
  
  // For reject — show reason modal instead
  if (action === 'reject') {
    openRejectReasonModal(djId);
    return;
  }
  
  // Everything else stays the same (approve, remove, clear-report)
  pendingAction = { action, dj };
  
  const titles = {
    'approve': 'Approve DJ',
    'remove': 'Remove DJ',
    'clear-report': 'Clear Report'
  };
  
  const safeName = escapeHtml(dj.name);
  const messages = {
    'approve': `Are you sure you want to approve <strong>${safeName}</strong>? They will be listed as a verified DJ on the platform immediately.`,
    'remove': `Are you sure you want to remove <strong>${safeName}</strong> from verified DJs? This action can be reversed.`,
    'clear-report': `Clear all reports for <strong>${safeName}</strong>? This will remove all flags from their profile.`
  };
  
  document.getElementById('confirmTitle').textContent = titles[action] || 'Confirm';
  document.getElementById('confirmMessage').innerHTML = messages[action] || 'Are you sure?';
  document.getElementById('confirmActionBtn').onclick = () => executeAction();
  
  openModal('confirmModal');
}


function executeAction() {
  if (!pendingAction) return;
  
  const { action, dj } = pendingAction;
  
  switch(action) {
    case 'approve':
      dj.status = 'verified';
      dj.rejectionReason = null;
      showToast(`${dj.name} approved successfully!`, 'success');
      break;
    case 'reject':
      dj.status = 'rejected';
      dj.rejectionReason = 'Application rejected by admin';
      showToast(`${dj.name}'s application rejected.`, 'error');
      break;
    case 'remove':
      dj.status = 'rejected';
      dj.rejectionReason = 'Removed from verified list by admin';
      showToast(`${dj.name} removed from verified DJs.`, 'error');
      break;
    case 'clear-report':
      dj.reports = 0;
      dj.reportedBy = null;
      dj.reportReason = null;
      dj.reportDate = null;
      showToast(`Reports cleared for ${dj.name}.`, 'success');
      break;
  }
  
  // Pls replace with your endpoint 
  // Example:
  // fetch(`https://your-api.com/api/admin/djs/${dj.id}`, {
  //   method: 'PATCH',
  //   headers: { 'Content-Type': 'application/json' },
  //   body: JSON.stringify({ status: dj.status })
  // })
  // .then(res => res.json())
  // .then(data => console.log('Updated:', data))
  // .catch(err => console.error('Error:', err));
  
  console.log(`[API Placeholder] ${action.toUpperCase()} — DJ #${dj.id} (${dj.name})`);
  
  closeModal('confirmModal');
  pendingAction = null;
  renderAll();
}

function openModal(id) {
  document.getElementById(id).classList.add('active');
  document.body.style.overflow = 'hidden';
}

function closeModal(id) {
  document.getElementById(id).classList.remove('active');
  document.body.style.overflow = '';
}

document.addEventListener('click', (e) => {
  if (e.target.classList.contains('modal-overlay')) {
    e.target.classList.remove('active');
    document.body.style.overflow = '';
  }
});

document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') {
    document.querySelectorAll('.modal-overlay.active').forEach(modal => {
      modal.classList.remove('active');
    });
    document.body.style.overflow = '';
  }
});

function showToast(message, type = 'success') {
  const toast = document.getElementById('toast');
  const icon = toast.querySelector('i');
  const text = document.getElementById('toastMessage');
  
  text.textContent = message;
  toast.className = `toast ${type}`;
  icon.className = type === 'success' ? 'fas fa-check-circle' : 'fas fa-times-circle';
  
  toast.classList.add('show');
  
  clearTimeout(toast._timeout);
  toast._timeout = setTimeout(() => {
    toast.classList.remove('show');
  }, 3500);
}

function formatDate(dateString) {
  const options = { year: 'numeric', month: 'short', day: 'numeric' };
  return new Date(dateString).toLocaleDateString('en-ZA', options);
}

console.log('✅ Admin panel initialized — no login required');
console.log('🔌 Ready for API endpoint integration');