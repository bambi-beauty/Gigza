// =============================================
// GIGZA — BOOKING PAGE
// =============================================
// NOTE ON DATA: this page has no backend yet, so bookings are stored in the
// browser's localStorage under 'gigza_bookings'. The admin Payments page reads
// from the same localStorage key, so if you open both pages in the same browser
// you'll see a booking made here show up there. Once you build a real API,
// replace loadBookings()/saveBookings() below with fetch() calls, and remove
// the localStorage bridge entirely — it's only here to make the demo click
// through end-to-end without a server.

const SERVICE_FEE_PERCENT = 0.10; // Gigza's commission — client pays this on top of the DJ's rate

// In production, fetch this list from your API, e.g. GET /api/djs?status=verified
// These IDs match the sample DJs in admin.js (DJ Zee=1, DJ Melody=3, Lebo P.=4, Thando M.=5)
// so a real backend could correlate a booking back to the right DJ record.
const BOOKABLE_DJS = [
  { id: 1, name: 'DJ Zee', genre: 'Amapiano', pricing: 2500 },
  { id: 3, name: 'DJ Melody', genre: 'Afro Tech', pricing: 3500 },
  { id: 4, name: 'Lebo P.', genre: 'Events Photography', pricing: 3000 },
  { id: 5, name: 'Thando M.', genre: 'MC / Host', pricing: 1500 },
];

let selectedDJ = null;

// ---------- LOCALSTORAGE BRIDGE (stand-in for a real backend — see note above) ----------
function loadBookings() {
  try {
    const raw = localStorage.getItem('gigza_bookings');
    return raw ? JSON.parse(raw) : [];
  } catch (e) {
    console.error('Could not read bookings from storage:', e);
    return [];
  }
}

function saveBookings(bookings) {
  try {
    localStorage.setItem('gigza_bookings', JSON.stringify(bookings));
  } catch (e) {
    console.error('Could not save booking to storage:', e);
  }
}

function generateBookingRef() {
  const stamp = Date.now().toString(36).toUpperCase();
  const rand = Math.random().toString(36).slice(2, 6).toUpperCase();
  return `GIGZA-${stamp}-${rand}`;
}

// ---------- DJ SELECTION ----------
function renderDJSelect() {
  const grid = document.getElementById('djSelectGrid');
  grid.innerHTML = BOOKABLE_DJS.map(dj => {
    const initials = dj.name.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase();
    return `
      <div class="dj-option" data-dj-id="${dj.id}">
        <div class="dj-option-avatar">${initials}</div>
        <div class="dj-option-info">
          <h4>${dj.name}</h4>
          <span>${dj.genre}</span>
          <span class="dj-option-price">R${dj.pricing.toLocaleString('en-ZA')}</span>
        </div>
      </div>
    `;
  }).join('');

  grid.querySelectorAll('.dj-option').forEach(el => {
    el.addEventListener('click', () => {
      const djId = Number(el.dataset.djId);
      selectedDJ = BOOKABLE_DJS.find(d => d.id === djId);
      grid.querySelectorAll('.dj-option').forEach(o => o.classList.remove('selected'));
      el.classList.add('selected');
      renderPriceBreakdown();
      updatePayButton();
    });
  });
}

// ---------- PRICE BREAKDOWN ----------
function renderPriceBreakdown() {
  const container = document.getElementById('priceBreakdown');
  if (!selectedDJ) {
    container.innerHTML = `<p class="price-placeholder">Select a DJ above to see pricing.</p>`;
    return;
  }
  const serviceFee = Math.round(selectedDJ.pricing * SERVICE_FEE_PERCENT);
  const total = selectedDJ.pricing + serviceFee;

  container.innerHTML = `
    <div class="price-row"><span>${selectedDJ.name} booking fee</span><span>R${selectedDJ.pricing.toLocaleString('en-ZA')}</span></div>
    <div class="price-row"><span>Gigza service fee (10%)</span><span>R${serviceFee.toLocaleString('en-ZA')}</span></div>
    <div class="price-row total"><span>Total due</span><span>R${total.toLocaleString('en-ZA')}</span></div>
  `;
}

function getTotal() {
  if (!selectedDJ) return 0;
  const serviceFee = Math.round(selectedDJ.pricing * SERVICE_FEE_PERCENT);
  return selectedDJ.pricing + serviceFee;
}

function updatePayButton() {
  const btn = document.getElementById('payBtn');
  const text = document.getElementById('payBtnText');
  if (selectedDJ) {
    btn.disabled = false;
    text.textContent = `Pay R${getTotal().toLocaleString('en-ZA')} with PayFast`;
  } else {
    btn.disabled = true;
    text.textContent = 'Select a DJ to continue';
  }
}

// ---------- FORM SUBMIT ----------
function showFormError(message) {
  const el = document.getElementById('formError');
  el.textContent = message;
  el.classList.add('show');
}

function hideFormError() {
  document.getElementById('formError').classList.remove('show');
}

document.getElementById('bookingForm').addEventListener('submit', (e) => {
  e.preventDefault();
  hideFormError();

  if (!selectedDJ) {
    showFormError('Please select a DJ before continuing.');
    return;
  }

  const clientName = document.getElementById('clientName').value.trim();
  const clientEmail = document.getElementById('clientEmail').value.trim();
  const clientPhone = document.getElementById('clientPhone').value.trim();
  const eventType = document.getElementById('eventType').value;
  const eventDate = document.getElementById('eventDate').value;
  const eventLocation = document.getElementById('eventLocation').value.trim();

  if (!clientName || !clientEmail || !clientPhone || !eventType || !eventDate || !eventLocation) {
    showFormError('Please fill in all fields before paying.');
    return;
  }

  const today = new Date().toISOString().split('T')[0];
  if (eventDate < today) {
    showFormError('Event date can\'t be in the past.');
    return;
  }

  const djRate = selectedDJ.pricing;
  const serviceFee = Math.round(djRate * SERVICE_FEE_PERCENT);
  const total = djRate + serviceFee;

  const booking = {
    ref: generateBookingRef(),
    djId: selectedDJ.id,
    djName: selectedDJ.name,
    clientName,
    clientEmail,
    clientPhone,
    eventType,
    eventDate,
    eventLocation,
    djRate,
    serviceFee,
    total,
    // 'pending' until PayFast confirms payment. A real backend flips this to 'paid'
    // only when it receives PayFast's server-to-server ITN notification — never
    // based on the browser just landing back on the return_url, since that can be
    // faked by anyone who knows the URL pattern.
    paymentStatus: 'pending',
    paymentMethod: 'payfast',
    payoutStatus: 'not_due',
    payoutAmount: djRate, // platform keeps the service fee as commission
    payoutRef: null,
    payoutDate: null,
    createdAt: new Date().toISOString(),
    paidAt: null,
  };

  const bookings = loadBookings();
  bookings.push(booking);
  saveBookings(bookings);

  window.gigzaPayfast.submitToPayfast(booking);
});

// ---------- HANDLE RETURN FROM PAYFAST ----------
function handleReturnFromPayfast() {
  const params = new URLSearchParams(window.location.search);
  const status = params.get('status');
  const ref = params.get('ref');
  if (!status || !ref) return false;

  const bookings = loadBookings();
  const booking = bookings.find(b => b.ref === ref);

  if (status === 'success') {
    // DEMO-ONLY SIMPLIFICATION: normally you would NOT mark a booking as paid
    // just because the browser came back to this URL — that can be faked. A real
    // implementation waits for PayFast's server-to-server notify_url callback
    // and only then marks the booking as paid. This demo does it here purely so
    // you can see the full flow working without a backend.
    if (booking) {
      booking.paymentStatus = 'paid';
      booking.paidAt = new Date().toISOString();
      booking.payoutStatus = 'due';
      saveBookings(bookings);
    }
    document.getElementById('formView').style.display = 'none';
    document.getElementById('successView').style.display = 'flex';
    document.getElementById('successRef').textContent = ref;
    return true;
  }

  if (status === 'cancelled') {
    if (booking) {
      booking.paymentStatus = 'failed';
      saveBookings(bookings);
    }
    document.getElementById('formView').style.display = 'none';
    document.getElementById('cancelledView').style.display = 'flex';
    return true;
  }

  return false;
}

// ---------- INIT ----------
document.addEventListener('DOMContentLoaded', () => {
  const handledReturn = handleReturnFromPayfast();
  if (!handledReturn) {
    renderDJSelect();
    renderPriceBreakdown();
    updatePayButton();

    // Default the date picker's minimum to today
    document.getElementById('eventDate').min = new Date().toISOString().split('T')[0];
  }
});
