// =============================================
// GIGZA AI VERIFICATION ENGINE
// Using free, open-source tools only
// =============================================

class GigzaVerificationEngine {
  constructor() {
    this.confidenceThresholds = {
      autoApprove: 75,
      softApprove: 55,
      flagForReview: 30,
      fullReview: 0
    };

    this.creativeTypes = {
      dj: {
        label: 'DJ',
        icon: 'fa-music',
        weightOverrides: { portfolio: 0.35, social: 0.15 }
      },
      photographer: {
        label: 'Photographer',
        icon: 'fa-camera',
        weightOverrides: { portfolio: 0.35, social: 0.20 }
      },
      videographer: {
        label: 'Videographer',
        icon: 'fa-video',
        weightOverrides: { portfolio: 0.35, social: 0.15 }
      },
      mc: {
        label: 'MC / Host',
        icon: 'fa-microphone',
        weightOverrides: { social: 0.25, readiness: 0.20 }
      },
      makeupArtist: {
        label: 'Makeup Artist',
        icon: 'fa-paint-brush',
        weightOverrides: { portfolio: 0.35, social: 0.20 }
      }
    };
  }

  // ---------- MAIN VERIFICATION PIPELINE ----------

  async verifyCreative(creative) {
    console.log(`🔍 Analyzing: ${creative.name} (${creative.type})`);

    const typeConfig = this.creativeTypes[creative.type] || this.creativeTypes.dj;

    // Run all checks
    const portfolioScore = await this.analyzePortfolio(creative, typeConfig);
    const identityScore = await this.verifyIdentity(creative);
    const socialScore = await this.analyzeSocialProof(creative);
    const readinessScore = await this.assessReadiness(creative);
    const riskScore = await this.assessRisk(creative);

    // ---- Weighted confidence (FIXED: normalized so overrides always sum to 1.0) ----
    const weights = typeConfig.weightOverrides || {};
    const rawWeights = {
      portfolio: weights.portfolio || 0.30,
      identity: weights.identity || 0.25,
      social: weights.social || 0.20,
      readiness: weights.readiness || 0.15,
      risk: weights.risk || 0.10
    };
    const weightTotal = Object.values(rawWeights).reduce((a, b) => a + b, 0);
    const finalWeights = Object.fromEntries(
      Object.entries(rawWeights).map(([k, v]) => [k, v / weightTotal])
    );

    let confidence = Math.round(
      (portfolioScore * finalWeights.portfolio) +
      (identityScore * finalWeights.identity) +
      (socialScore * finalWeights.social) +
      (readinessScore * finalWeights.readiness) +
      ((100 - riskScore) * finalWeights.risk)
    );

    const flags = this.generateFlags({ portfolioScore, identityScore, socialScore, readinessScore, riskScore, creative });

    // ---- Hard gate: never auto-approve on unverified identity, regardless of weighted score ----
    // The identity score today is a heuristic placeholder (real OCR/face-match are not yet wired in),
    // so a high weighted average must not translate into "Auto-approved" if identity is weak.
    const identityUnverified = identityScore < 50 || !creative.livenessVerified;
    if (identityUnverified && confidence >= this.confidenceThresholds.autoApprove) {
      confidence = this.confidenceThresholds.autoApprove - 1; // drop into soft-approve/flag territory
    }

    const outcome = this.determineOutcome(confidence, flags);
    const reviewTips = this.generateReviewTips({ portfolioScore, identityScore, socialScore, readinessScore, riskScore, creative, identityUnverified });

    const result = {
      creative: creative.name,
      type: creative.type,
      confidence,
      scores: { portfolio: portfolioScore, identity: identityScore, social: socialScore, readiness: readinessScore, risk: riskScore },
      flags,
      reviewTips,
      outcome,
      timestamp: new Date().toISOString(),
      verified: outcome.status === 'approved',
      requiresAdmin: outcome.requiresAdmin
    };

    console.log(`✅ ${creative.name}: ${confidence}% — ${outcome.status}`);
    return result;
  }

  // ---------- PORTFOLIO ANALYSIS (Free Tools) ----------

  async analyzePortfolio(creative, typeConfig) {
    let score = 50;

    if (!creative.portfolioUrl) return 10;
    if (this.isValidUrl(creative.portfolioUrl)) score += 15;

    // Type-specific checks
    switch (creative.type) {
      case 'dj':
        score += this.analyzeAudioQuality(creative);  // Free: check bitrate, length, silence
        break;
      case 'photographer':
      case 'makeupArtist':
        score += this.analyzeImageQuality(creative);  // Free: check resolution, metadata
        break;
      case 'videographer':
        score += this.analyzeVideoQuality(creative);  // Free: check duration, resolution
        break;
    }

    // Check for content originality using free heuristic
    if (creative.bio && !this.detectCopyPasteBio(creative.bio)) score += 5;

    return Math.min(100, Math.max(0, score));
  }

  // ---------- FREE AUDIO ANALYSIS ----------

  analyzeAudioQuality(creative) {
    let score = 0;

    if (creative.mixCount >= 5) score += 20;
    else if (creative.mixCount >= 3) score += 12;
    else if (creative.mixCount >= 1) score += 5;

    if (creative.avgMixDuration > 900) score += 10;
    else if (creative.avgMixDuration > 300) score += 5;

    if (creative.avgBitrate >= 320) score += 8;
    else if (creative.avgBitrate >= 192) score += 4;

    if (creative.genres && creative.genres.length >= 3) score += 5;

    return score;
  }

  // ---------- FREE IMAGE ANALYSIS ----------

  analyzeImageQuality(creative) {
    let score = 0;

    if (creative.galleryCount >= 10) score += 20;
    else if (creative.galleryCount >= 5) score += 12;
    else if (creative.galleryCount >= 1) score += 5;

    if (creative.avgImageResolution > 2000) score += 8;
    else if (creative.avgImageResolution > 1000) score += 4;

    if (creative.hasBeforeAfter) score += 10;

    if (creative.styles && creative.styles.length >= 2) score += 5;

    return score;
  }

  // ---------- FREE VIDEO ANALYSIS ----------

  analyzeVideoQuality(creative) {
    let score = 0;

    if (creative.hasShowreel) score += 15;
    if (creative.videoCount >= 5) score += 12;
    else if (creative.videoCount >= 2) score += 5;

    if (creative.avgVideoDuration > 60) score += 8;

    if (creative.videoQuality >= 1080) score += 8;
    else if (creative.videoQuality >= 720) score += 4;

    return score;
  }

  // ---------- IDENTITY VERIFICATION (Free Tools) ----------

  async verifyIdentity(creative) {
    let score = 50;

    if (!creative.idDocument) return 15;

    // --- ID Number Checksum Validation (FREE, real validation — not simulated) ---
    // South African ID numbers are 13 digits: YYMMDD SSSS C A Z
    // where Z is a Luhn checksum digit. This actually catches made-up/invalid numbers,
    // unlike a plain "is it 13 characters" check.
    const idCheck = this.validateSAIdNumber(creative.idNumber, creative.dateOfBirth);
    score += idCheck.score;

    // --- Face Matching Simulation ---
    // NOTE: this is still a placeholder. It only checks that two different files were
    // uploaded — it does NOT compare faces. Do not treat this score as real identity proof.
    // In production, use face-api.js (free) with FaceNet models:
    // const img1 = await faceapi.fetchImage(creative.profilePhoto);
    // const img2 = await faceapi.fetchImage(creative.idPhoto);
    // const descriptor1 = await faceapi.computeFaceDescriptor(img1);
    // const descriptor2 = await faceapi.computeFaceDescriptor(img2);
    // const distance = faceapi.euclideanDistance(descriptor1, descriptor2);
    // if (distance < 0.6) score += 20; // Match found
    const faceMatchScore = this.simulateFaceMatch(creative);
    score += faceMatchScore;

    // --- Liveness Detection ---
    if (creative.livenessVerified) score += 10;

    // Name consistency
    if (creative.fullName && creative.idName) {
      const nameMatch = this.fuzzyNameMatch(creative.fullName, creative.idName);
      if (nameMatch > 0.9) score += 10;
      else if (nameMatch > 0.7) score += 5;
      else score -= 20;
    }

    return Math.min(100, Math.max(0, score));
  }

  // ---------- REAL SA ID CHECKSUM VALIDATION ----------
  // Replaces the old "length === 13" placeholder with an actual Luhn-style
  // checksum check plus a DOB-consistency check against the ID's embedded YYMMDD.
  validateSAIdNumber(idNumber, dateOfBirth) {
    if (!idNumber || !/^\d{13}$/.test(idNumber)) {
      return { score: 0, valid: false, reason: 'not 13 digits' };
    }

    const digits = idNumber.split('').map(Number);

    // Luhn checksum (used by SA ID numbers)
    let sum = 0;
    for (let i = 0; i < 12; i++) {
      let d = digits[i];
      if (i % 2 !== 0) { // even position from the right in 13-digit Luhn (0-indexed odd here)
        d *= 2;
        if (d > 9) d -= 9;
      }
      sum += d;
    }
    const checkDigit = (10 - (sum % 10)) % 10;
    const checksumValid = checkDigit === digits[12];

    if (!checksumValid) {
      return { score: -10, valid: false, reason: 'checksum failed, likely fabricated ID number' };
    }

    let score = 10; // valid checksum is a meaningfully stronger signal than "right length"

    // Cross-check embedded YYMMDD against submitted date of birth, if provided
    if (dateOfBirth) {
      const yy = idNumber.slice(0, 2);
      const mm = idNumber.slice(2, 4);
      const dd = idNumber.slice(4, 6);
      const dob = new Date(dateOfBirth);
      const dobYY = String(dob.getFullYear() % 100).padStart(2, '0');
      const dobMM = String(dob.getMonth() + 1).padStart(2, '0');
      const dobDD = String(dob.getDate()).padStart(2, '0');

      if (yy === dobYY && mm === dobMM && dd === dobDD) {
        score += 5;
      } else {
        score -= 8; // ID's embedded DOB doesn't match submitted DOB — inconsistency worth flagging
      }
    }

    return { score, valid: true, reason: 'checksum passed' };
  }

  // Simulate FaceNet face matching
  simulateFaceMatch(creative) {
    // In reality, face-api.js would compare photos. Here we only check that both
    // photos exist and are different file references — this is NOT a face match.
    if (creative.profilePhoto && creative.idPhoto) {
      if (creative.profilePhoto !== creative.idPhoto) return 15;
      return 5; // Same photo — suspicious
    }
    return 0;
  }

  // ---------- SOCIAL PROOF ANALYSIS ----------

  async analyzeSocialProof(creative) {
    let score = 50;
    const socials = creative.socialLinks || {};
    const platforms = Object.keys(socials).filter(k => socials[k]);

    if (platforms.length === 0) return 30;
    score += Math.min(platforms.length * 5, 15);

    for (const platform of platforms) {
      const data = socials[platform];

      if (data.followers > 0) {
        const engagementRate = data.avgLikes / data.followers;
        if (engagementRate > 0.05) score += 12;
        else if (engagementRate > 0.02) score += 8;
        else if (engagementRate < 0.003) score -= 10;
      }

      if (data.followers > 5000) score += 3;
      else if (data.followers > 1000) score += 2;

      if (data.accountAge > 365) score += 8;
      else if (data.accountAge > 90) score += 4;

      if (data.followerToFollowingRatio > 100) score -= 10;
      if (data.avgComments < data.avgLikes * 0.01) score -= 5;
    }

    return Math.min(100, Math.max(0, score));
  }

  // ---------- PROFESSIONAL READINESS ----------

  assessReadiness(creative) {
    let score = 50;

    if (creative.bio) {
      const bioLength = creative.bio.length;
      if (bioLength > 200) score += 12;
      else if (bioLength > 100) score += 8;
      else if (bioLength > 50) score += 4;

      if (/contact|book|hire|available/i.test(creative.bio)) score += 5;
      if (!this.detectCopyPasteBio(creative.bio)) score += 8;

      if (creative.bio.split('.').length >= 3) score += 3;
      if (/[A-Z]/.test(creative.bio[0])) score += 2;
    } else {
      score -= 20;
    }

    if (creative.equipment && creative.equipment.length > 0) score += 8;
    if (creative.pricing && creative.pricing > 0) score += 5;
    if (creative.availability && creative.availability.length > 0) score += 5;

    return Math.min(100, Math.max(0, score));
  }

  // ---------- RISK ASSESSMENT ----------

  assessRisk(creative) {
    let riskScore = 0;

    if (creative.previousRejections > 2) riskScore += 30;
    else if (creative.previousRejections > 0) riskScore += 15;

    if (creative.applicationCount > 3) riskScore += 20;

    // Disposable email is a strong standalone fraud signal — weighted higher
    // and also surfaced as its own flag (see generateFlags) rather than only
    // relying on the aggregate risk score crossing a threshold.
    if (creative.emailDomain && this.isDisposableEmail(creative.emailDomain)) riskScore += 35;

    if (this.detectCopyPasteBio(creative.bio)) riskScore += 10;
    if (creative.bio && this.containsSpamKeywords(creative.bio)) riskScore += 15;
    if (creative.applicationSpeed < 60) riskScore += 10;

    return Math.min(100, riskScore);
  }

  // ---------- FLAGS & OUTCOME ----------

  // ---------- REVIEW TIPS FOR ADMINS ----------
  // This is different from generateFlags: flags say "something is wrong."
  // This says "here's specifically what to go look at, and why" — written for
  // a human who's about to spend 30 seconds deciding pass/fail, not for logging.
  generateReviewTips({ portfolioScore, identityScore, socialScore, readinessScore, riskScore, creative, identityUnverified }) {
    const tips = [];

    // ---- Identity ----
    if (!creative.idDocument) {
      tips.push({ icon: '🆔', text: 'No ID document was uploaded at all. This alone should block approval until they submit one.' });
    } else if (identityScore < 50) {
      tips.push({ icon: '🆔', text: 'ID checks came back weak. Note: the face-photo comparison is still a placeholder in this system (it doesn\'t actually compare faces yet), so manually eyeball their profile photo against their ID photo before approving.' });
    } else if (identityUnverified) {
      tips.push({ icon: '🆔', text: 'ID passed its checks, but liveness wasn\'t confirmed (no short video/selfie check). Worth a quick manual look before auto-approving.' });
    }

    if (creative.idNumber && creative.dateOfBirth) {
      const check = this.validateSAIdNumber(creative.idNumber, creative.dateOfBirth);
      if (!check.valid) {
        tips.push({ icon: '⚠️', text: 'The ID number failed a checksum test. It doesn\'t look like a real, issued South African ID number, which is a strong sign of a fabricated application.' });
      }
    }

    // ---- Portfolio ----
    if (portfolioScore < 30) {
      tips.push({ icon: '📁', text: 'Very little portfolio content (few or no mixes/photos/videos, or no portfolio link at all). Ask for real work samples before approving, since an empty portfolio is the easiest thing for a fake account to fake.' });
    } else if (portfolioScore < 50) {
      tips.push({ icon: '📁', text: 'Portfolio is thin. Not necessarily a red flag for a newcomer, but worth a quick look at the actual content quality, not just the count.' });
    }

    // ---- Social ----
    if (socialScore < 30) {
      tips.push({ icon: '📱', text: 'Little to no social presence to cross-check against. Could just be a new creative, but it also means there\'s less outside evidence this is a real, active person.' });
    } else if (socialScore < 50 && portfolioScore > 60) {
      tips.push({ icon: '💡', text: 'Strong portfolio but weak social following, which is common for genuinely talented newcomers. Don\'t penalize this alone.' });
    }

    // ---- Risk-specific ----
    if (creative.emailDomain && this.isDisposableEmail(creative.emailDomain)) {
      tips.push({ icon: '📧', text: 'They signed up with a disposable/temporary email address. This is one of the strongest single signals of a throwaway or fraudulent account, so it\'s worth asking for a real email before proceeding.' });
    }
    if (this.detectCopyPasteBio(creative.bio)) {
      tips.push({ icon: '📋', text: 'The bio reads like a generic template (stock phrases like "hardworking," "team player," etc.) rather than something written about this specific person.' });
    }
    if (creative.bio && this.containsSpamKeywords(creative.bio)) {
      tips.push({ icon: '🚫', text: 'The bio contains spammy, hype-heavy language ("best in the world," "100% guarantee," etc.). Real professionals rarely write like this, so it\'s worth a second look.' });
    }
    if (creative.previousRejections > 0) {
      tips.push({ icon: '🔁', text: `This person has been rejected ${creative.previousRejections} time(s) before. Check what changed since the last rejection before approving.` });
    }

    // ---- Readiness ----
    if (readinessScore < 40) {
      tips.push({ icon: '📝', text: 'Bio and profile completeness is low (short bio, no equipment listed, no pricing/availability set). This makes it hard to judge professionalism either way.' });
    }

    // If everything looks genuinely clean, say so explicitly rather than leaving an empty list
    if (tips.length === 0) {
      tips.push({ icon: '✅', text: 'Nothing specific stood out as a concern. This still isn\'t a substitute for a human glancing at the portfolio and ID photo once, just that the automated checks didn\'t flag anything.' });
    }

    return tips;
  }

  generateFlags(scores) {
    const flags = [];

    if (scores.identityScore < 25) {
      flags.push({
        severity: 'high',
        icon: '🆔',
        category: 'identity',
        message: 'Identity verification failed',
        detail: 'ID document missing, invalid, or doesn\'t match profile photo',
        requiresAdmin: true
      });
    }

    // Standalone high-confidence signal: disposable email always forces a flag,
    // even if it doesn't push the aggregate risk score past 65 on its own.
    if (scores.creative && scores.creative.emailDomain && this.isDisposableEmail(scores.creative.emailDomain)) {
      flags.push({
        severity: 'high',
        icon: '📧',
        category: 'risk',
        message: 'Disposable email address detected',
        detail: 'Applicant used a temporary/disposable email provider, a common fraud pattern',
        requiresAdmin: true
      });
    }

    if (scores.riskScore > 65) {
      flags.push({
        severity: 'high',
        icon: '🚩',
        category: 'risk',
        message: 'High risk profile detected',
        detail: 'Multiple suspicious patterns, possibly a fraudulent account',
        requiresAdmin: true
      });
    }

    if (scores.portfolioScore < 30 && scores.identityScore < 50) {
      flags.push({
        severity: 'medium',
        icon: '📁',
        category: 'portfolio',
        message: 'Portfolio and identity concerns',
        detail: 'Unable to verify content and identity simultaneously',
        requiresAdmin: true
      });
    }

    if (scores.socialScore < 25 && scores.portfolioScore > 70) {
      flags.push({
        severity: 'low',
        icon: '📱',
        category: 'social',
        message: 'Strong portfolio, limited following',
        detail: 'Talented but undiscovered, which is normal for newcomers',
        requiresAdmin: false
      });
    }

    return flags;
  }

  determineOutcome(confidence, flags) {
    const hasHighSeverity = flags.some(f => f.severity === 'high');
    const hasMediumRequiringAdmin = flags.some(f => f.severity === 'medium' && f.requiresAdmin);

    if (hasHighSeverity || confidence < 30) {
      return {
        status: 'full_review',
        requiresAdmin: true,
        priority: 'high',
        message: 'Full admin review required',
        color: '#FF1744'
      };
    }

    if (hasMediumRequiringAdmin || confidence < 55) {
      return {
        status: 'flagged',
        requiresAdmin: true,
        priority: 'medium',
        message: 'Flagged for admin review',
        color: '#FF9100'
      };
    }

    return {
      status: 'approved',
      requiresAdmin: false,
      priority: 'low',
      message: confidence >= 75 ? 'Auto-approved' : 'Approved with AI notes',
      color: confidence >= 75 ? '#00C853' : '#00D4FF'
    };
  }

  // ---------- HELPERS ----------

  isValidUrl(string) {
    try { new URL(string); return true; } catch { return false; }
  }

  fuzzyNameMatch(name1, name2) {
    const normalize = (s) => s.toLowerCase().replace(/[^a-z]/g, '');
    const n1 = normalize(name1);
    const n2 = normalize(name2);
    if (n1 === n2) return 1.0;
    if (n1.includes(n2) || n2.includes(n1)) return 0.9;
    const longer = n1.length > n2.length ? n1 : n2;
    const shorter = n1.length > n2.length ? n2 : n1;
    let matches = 0;
    for (let i = 0; i < shorter.length; i++) {
      if (longer.includes(shorter[i])) matches++;
    }
    return matches / longer.length;
  }

  isPlausibleAge(dob, experience) {
    const birthYear = new Date(dob).getFullYear();
    const age = new Date().getFullYear() - birthYear;
    return age - experience >= 12;
  }

  detectCopyPasteBio(bio) {
    if (!bio) return false;
    const templates = ['passionate about', 'hardworking', 'team player', 'i am a creative', 'looking for opportunities'];
    const lower = bio.toLowerCase();
    return templates.filter(p => lower.includes(p)).length >= 3;
  }

  isDisposableEmail(domain) {
    const disposables = ['mailinator.com', 'tempmail.com', 'guerrillamail.com', '10minutemail.com', 'yopmail.com'];
    return disposables.includes(domain.toLowerCase());
  }

  containsSpamKeywords(text) {
    if (!text) return false;
    const spam = ['make money fast', 'get rich', '100% guarantee', 'best in the world', 'number one'];
    const lower = text.toLowerCase();
    return spam.some(k => lower.includes(k));
  }
}

// ---------- GLOBAL INSTANCE ----------
const verificationEngine = new GigzaVerificationEngine();
window.verificationEngine = verificationEngine;

console.log('🤖 Gigza AI Verification Engine ready');
console.log('🔧 Using free tools: Tesseract OCR (placeholder), FaceNet/face-api.js (placeholder), heuristics + real SA ID checksum validation');
